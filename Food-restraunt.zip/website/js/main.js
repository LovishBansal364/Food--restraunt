// active navbar
let nav = document.querySelector('.navigation-wrap');
window.onscroll = function () {
    if(document.documentElement.scrollTop > 20){
        nav.classList.add("scroll-on");
    }else{
        nav.classList.remove("scroll-on");
    }
}

// nav hide 
let navBar = document.querySelectorAll(".nav-link");
let navCollapse = document.querySelector('.navbar-collapse.collapse');
navBar.forEach(function(a){
    a.addEventListener("click", function(){
        navCollapse.classList.remove("show");
    });
});



// counter-design
document.addEventListener('DOMContentLoaded', () => {
    function counter(id, start, end, duration){
        let obj = document.getElementById(id),
        current = start,
        range = end - start,
        increment = end > start ? 1 : -1,         //ternary operator
        step = Math.abs(Math.floor(duration / range)),
        timer = setInterval(() => {
            current += increment;
            obj.textContent = current;
            if(current == end){
                clearInterval(timer);
            }
        }, step);
    }
    counter("count1", 0, 1287, 3000);
    counter("count2", 100, 2286, 2500);
    counter("count3", 0, 1440, 3000);
    counter("count4", 0, 2310, 3000);
});

// Order now render 
function render(){
    window.location.href = "./order.html";
}

// read more regions 
function regions(){
    window.location.href = "./regions.html";
}

// learn more 
function learn(){
    window.location.href = "./learn.html"
}

// orders
function order(){
    window.location.href = "./pay.html";
}
function order1(){
    window.location.href = "./pay1.html";
}
function order2(){
    window.location.href = "./pay2.html";
}
function order3(){
    window.location.href = "./pay3.html";
}
function order4(){
    window.location.href = "./pay4.html";
}
function order5(){
    window.location.href = "./pay5.html";
}
function order6(){
    window.location.href = "./pay6.html";
}
function order7(){
    window.location.href = "./pay7.html";
}
function order8(){
    window.location.href = "./pay8.html";
}
